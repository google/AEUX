/*

SketchterEffects
Copyright (c) 2016
DESCRIPTION

*/

//encapsulate the script in a function to avoid global variables
(function (thisObj) {
  // json2.js (minified) - This needs to be at the top of the script or at least before JSON.stringify is called
  // This is open-source software
  if(typeof JSON!=="object"){JSON={}}(function(){function f(n){return n<10?"0"+n:n}if(typeof Date.prototype.toJSON!=="function"){Date.prototype.toJSON=function(key){return isFinite(this.valueOf())?this.getUTCFullYear()+"-"+f(this.getUTCMonth()+1)+"-"+f(this.getUTCDate())+"T"+f(this.getUTCHours())+":"+f(this.getUTCMinutes())+":"+f(this.getUTCSeconds())+"Z":null};String.prototype.toJSON=Number.prototype.toJSON=Boolean.prototype.toJSON=function(key){return this.valueOf()}}var cx=/[\u0000\u00ad\u0600-\u0604\u070f\u17b4\u17b5\u200c-\u200f\u2028-\u202f\u2060-\u206f\ufeff\ufff0-\uffff]/g,escapable=/[\\\"\x00-\x1f\x7f-\x9f\u00ad\u0600-\u0604\u070f\u17b4\u17b5\u200c-\u200f\u2028-\u202f\u2060-\u206f\ufeff\ufff0-\uffff]/g,gap,indent,meta={"\b":"\\b","\t":"\\t","\n":"\\n","\f":"\\f","\r":"\\r",'"':'\\"',"\\":"\\\\"},rep;function quote(string){escapable.lastIndex=0;return escapable.test(string)?'"'+string.replace(escapable,function(a){var c=meta[a];return typeof c==="string"?c:"\\u"+("0000"+a.charCodeAt(0).toString(16)).slice(-4)})+'"':'"'+string+'"'}function str(key,holder){var i,k,v,length,mind=gap,partial,value=holder[key];if(value&&typeof value==="object"&&typeof value.toJSON==="function"){value=value.toJSON(key)}if(typeof rep==="function"){value=rep.call(holder,key,value)}switch(typeof value){case"string":return quote(value);case"number":return isFinite(value)?String(value):"null";case"boolean":case"null":return String(value);case"object":if(!value){return"null"}gap+=indent;partial=[];if(Object.prototype.toString.apply(value)==="[object Array]"){length=value.length;for(i=0;i<length;i+=1){partial[i]=str(i,value)||"null"}v=partial.length===0?"[]":gap?"[\n"+gap+partial.join(",\n"+gap)+"\n"+mind+"]":"["+partial.join(",")+"]";gap=mind;return v}if(rep&&typeof rep==="object"){length=rep.length;for(i=0;i<length;i+=1){if(typeof rep[i]==="string"){k=rep[i];v=str(k,value);if(v){partial.push(quote(k)+(gap?": ":":")+v)}}}}else{for(k in value){if(Object.prototype.hasOwnProperty.call(value,k)){v=str(k,value);if(v){partial.push(quote(k)+(gap?": ":":")+v)}}}}v=partial.length===0?"{}":gap?"{\n"+gap+partial.join(",\n"+gap)+"\n"+mind+"}":"{"+partial.join(",")+"}";gap=mind;return v}}if(typeof JSON.stringify!=="function"){JSON.stringify=function(value,replacer,space){var i;gap="";indent="";if(typeof space==="number"){for(i=0;i<space;i+=1){indent+=" "}}else{if(typeof space==="string"){indent=space}}rep=replacer;if(replacer&&typeof replacer!=="function"&&(typeof replacer!=="object"||typeof replacer.length!=="number")){throw new Error("JSON.stringify")}return str("",{"":value})}}if(typeof JSON.parse!=="function"){JSON.parse=function(text,reviver){var j;function walk(holder,key){var k,v,value=holder[key];if(value&&typeof value==="object"){for(k in value){if(Object.prototype.hasOwnProperty.call(value,k)){v=walk(value,k);if(v!==undefined){value[k]=v}else{delete value[k]}}}}return reviver.call(holder,key,value)}text=String(text);cx.lastIndex=0;if(cx.test(text)){text=text.replace(cx,function(a){return"\\u"+("0000"+a.charCodeAt(0).toString(16)).slice(-4)})}if(/^[\],:{}\s]*$/.test(text.replace(/\\(?:["\\\/bfnrt]|u[0-9a-fA-F]{4})/g,"@").replace(/"[^"\\\n\r]*"|true|false|null|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?/g,"]").replace(/(?:^|:|,)(?:\s*\[)+/g,""))){j=eval("("+text+")");return typeof reviver==="function"?walk({"":j},""):j}throw new SyntaxError("JSON.parse")}}}());


  //================ VARIABLES ======================
  var scriptName = "SketchAE";
  var scriptVersion = '0.2';
  var defaultBoxText = 'Paste Sketch code';
  var labelColor;
  var clippingMask = null;
  var thisComp = null, symbolFolderName = 'Symbols', symbolFolder, imageFolderName = 'Images', imageFolder, inputFile;
  var compMult = 1;
  var relativePath = false;

  var icons = {
    paste: ['40 18 48 18 52.5833333 18.9166667 48 21 49 24 49.5 21 53.0849057 19.1132075 56 23 46 36 46 30 49 30 44 26 44 44 61 44 62 43 62 8 61 7 56 7 58 10 57 11 31 11 30 10 32 7 27 7 26 8 26 43 27 44 44 44 44 26 39 30 42 30 42 36 32 23 34.8536585 19.195122 38.5 22 37.5 25 40 21.5 45 21 39 21 35.3703704 18.9259259',
            '31.423584 10.0628662 34.4645094 6 38.1957739 6 40.1957739 4.76393202 41.648859 2.76393202 44 2 44 4 42.8272528 4.5647653 42.5376081 5.8337814 43.3491744 6.8514533 44.6508256 6.8514533 45.4623919 5.8337814 45.1727472 4.5647653 44 4 44 2 46.351141 2.76393202 47.8042261 4.76393202 49.8042261 6 53.4294807 6 56.4831543 10.0756836'],
    open:  ['40 18 48 18 52.5 18.9166667 48 21 49 24 49.5 21 53 19 56 23 46 36 46 30 49 30 44 26 44 45 59 45 60 44 60 13 51 4 49 4 58 13 50 13 50 4 29 4 28 5 28 12 31 12 31 8 43 8 43 9 31 9 31 11 39 11 39 12 28 12 28 44 29 45 44 45 44 26 39 30 42 30 42 36 32 23 34.8536585 19.195122 38.5 22 37.5 25 40 21.5 45 21 39 21 35.3703704 18.9259259']
  };


  // ================ FUNCTIONS =============
  function setComp () {
    thisComp = app.project.activeItem;
    if (!thisComp || !(thisComp instanceof CompItem)) {		// Make sure a comp is selected
      alert("Gotta select a comp first");
      return false;
    }
    workStart = thisComp.workAreaStart;
    workEnd = workStart + thisComp.workAreaDuration;
    fr = thisComp.frameRate;
    return true;
  }

  function buttonColor(parentObj, accentColor, buttonText) {
    lineWidth = 2;
    var btn = parentObj.add('button', undefined, '', {name:'ok'});
        btn.fillBrush = btn.graphics.newBrush( btn.graphics.BrushType.SOLID_COLOR, hexToArray(accentColor));

        btn.text = buttonText.toUpperCase();

        btn.fillBrush = btn.graphics.newBrush( btn.graphics.BrushType.SOLID_COLOR, hexToArray(accentColor));
        btn.textPen = btn.graphics.newPen (btn.graphics.PenType.SOLID_COLOR,hexToArray('#ffffff'), 1);
        btn.onDraw = gfxDraw;

    return btn;

    function gfxDraw() {
      { with (this) {
        graphics.drawOSControl();
        graphics.rectPath(0,0,size[0],size[1]);
        graphics.fillPath(fillBrush);
        if( text ) graphics.drawString(
          text,
          textPen,
          (size[0]-graphics.measureString (text,graphics.font,size[0])[0])/2,
          (size[1]-graphics.measureString (text,graphics.font,size[0])[1])/1.75,
          graphics.font);
      }}
    }
    function hexToArray(hexString) {
      var hexColor = hexString.replace('#', '');
      var r = parseInt(hexColor.slice(0, 2), 16) / 255,
          g = parseInt(hexColor.slice(2, 4), 16) / 255,
          b = parseInt(hexColor.slice(4, 6), 16) / 255;
      return [r, g, b, 1];
    }
  }
  function vecButton(parentObj, iconVec, iconColor, size) {    /// from sketch
    var vButton = parentObj.add('button', [0,0,size[0],size[1], undefined]);
        vButton.coord = vecToPoints(iconVec);
        vButton.fillColor = iconColor;
        vButton.onDraw = vecDraw;

        return vButton;

    function vecToPoints(vecCoord) {
      var points = [];
      var n;

      for(var i = 0; i < vecCoord.length; i++) {      // from AI
        var eachNum = vecCoord[i].split(' ');    // from AI [1,1 10,10, 25,50]
        var coordinates = [];
        var sets = [];

        for (var k = 0; k < eachNum.length; k+=2) {
          sets.push(eachNum[k] + ',' + eachNum[k+1]);
        }

        for (var j = 0; j < sets.length; j++) {
          n = sets[j].split(',');
          coordinates[j] = n;
          coordinates[j][0] = (parseFloat(coordinates[j][0]));
          coordinates[j][1] = (parseFloat(coordinates[j][1]));
        }
      sets = coordinates;
      points.push(sets);
      }
      return points;
    }

    function hexToArray(hexString) {
      var hexColor = hexString.replace('#', '');
      var r = parseInt(hexColor.slice(0, 2), 16) / 255,
          g = parseInt(hexColor.slice(2, 4), 16) / 255,
          b = parseInt(hexColor.slice(4, 6), 16) / 255;
      return [r, g, b, 1];
    }
    function vecDraw() {
      with ( this ) {
        graphics.drawOSControl();

        // draw background
        graphics.rectPath(0,0,size[0],size[1]);
        graphics.fillPath(graphics.newBrush(graphics.BrushType.SOLID_COLOR, hexToArray(iconColor)));

        // draw shape
        for (var i = 0; i < coord.length; i++) {
          var line = coord[i];

          graphics.newPath();
          graphics.moveTo(line[0][0], line[0][1]);
          for (var j = 0; j < line.length; j++) {
            graphics.lineTo(line[j][0], line[j][1]);
          }
          graphics.fillPath(graphics.newBrush(graphics.BrushType.SOLID_COLOR, [1,1,1,0.75]));
        }
      }
    }
  }

  function getCompMultiplier(artboardWidth) {
    if (!cb_newComp.value) {
      var scaleFac = thisComp.width / artboardWidth;
      return scaleFac;
    }
    if (ddl_compScale.selection.index === 0) {
      return 3;
    }
    if (ddl_compScale.selection.index === 1) {
      return 2;
    }
    if (ddl_compScale.selection.index === 2) {
      return 1;
    }
  }
  function buildLayers(entryText) {
    labelColor = 2;

    try {
    var sketchCode = new File();
    sketchCode = JSON.parse(File.decode(entryText));

    app.beginUndoGroup('Sketch Import');
      filterTypes(sketchCode);
    app.endUndoGroup();

    // close twirled layers
    app.executeCommand(2771);
    app.executeCommand(2771);

    } catch(e) {
      alert(e.toString() + "\nError on line: " + e.line.toString());
    }
  }
  function createSymbolFolder() {
    var hasSymbolFolder = false;
    for (var i = 1; i <= app.project.numItems; i++) {     // loop through all project items
      if (app.project.item(i) instanceof FolderItem) {    // find folders
        if (app.project.item(i).name == symbolFolderName) {     // check it's name
          hasSymbolFolder = true;
          symbolFolder = app.project.item(i);            // set the inspectorFolder var to the found folder
        }
      }
    }
    if (!hasSymbolFolder) {      // if no redline folder is found create one
      symbolFolder = app.project.items.addFolder(symbolFolderName);
    }
  }
  function createImageFolder() {
    var hasImageFolder = false;
    for (var i = 1; i <= app.project.numItems; i++) {     // loop through all project items
      if (app.project.item(i) instanceof FolderItem) {    // find folders
        if (app.project.item(i).name == imageFolderName) {     // check it's name
          hasImageFolder = true;
          imageFolder = app.project.item(i);            // set the inspectorFolder var to the found folder
        }
      }
    }
    if (!hasImageFolder) {      // if no redline folder is found create one
      imageFolder = app.project.items.addFolder(imageFolderName);
    }
  }
  function createSymbol(layer, opt_parent) {
    var symbol;
    // check if the symbol precomp already exists
    var symbolExists = false;
    for (var i = 1; i <= symbolFolder.items.length; i++) {
      if (symbolFolder.item(i).comment === layer.symbolID) {
        symbolExists = true;
        symbol = symbolFolder.item(i);
        break;
      }
    }

    // create new symbol
    if (!symbolExists){
      symbol = app.project.items.addComp(layer.name, Math.round(layer.symbolSize[0]), Math.round(layer.symbolSize[1]), thisComp.pixelAspect, thisComp.duration, thisComp.frameRate);
      symbol.parentFolder = symbolFolder;
      symbol.comment = layer.symbolID;

      var mainComp = thisComp;          // store the mainComp
      thisComp = symbol;                // set thisComp to the new symbol comp to create in
      var compMultStorage = compMult;   // temp storage for the compMult value
      compMult = 1;                     // set compMult to 1x
      filterTypes(layer.layers, null);
      compMult = compMultStorage;   // set compMult back to artboard multiplier
      thisComp = mainComp;              // reset thisComp to kthe mainComp
    }

    return symbol;
  }
  function filterTypes(sketchCode, opt_parent) {
    var groupParent = null;
    if (opt_parent != null) {
      groupParent = opt_parent;
    }
    for (var i = 0; i < sketchCode.length; i++) {
      if (sketchCode[i].type === 'MSLayerGroup') {
        aeGroup(sketchCode[i], groupParent);
      }
      if (sketchCode[i].type === 'MSSymbolInstance') {
        aeSymbol(sketchCode[i], groupParent);
      }
      if (sketchCode[i].type === 'CompoundShape') {
        // alert('look a CompoundShape')
        aeCompound(sketchCode[i], groupParent);
      }
      if (sketchCode[i].type === 'MSRectangleShape') {
        aeRect(sketchCode[i], groupParent);
      }
      if (sketchCode[i].type === 'MSOvalShape') {
        aeEllipse(sketchCode[i], groupParent);
      }
      if (sketchCode[i].type === 'MSTextLayer') {
        aeText(sketchCode[i], groupParent);
      }
      if (sketchCode[i].type === 'MSBitmapLayer') {
        aeImage(sketchCode[i], groupParent);
      }
      if (sketchCode[i].type === 'MSShapePathLayer') {
        aePath(sketchCode[i], groupParent);
      }
      if (sketchCode[i].type === 'MSArtboardGroup' || sketchCode[i].type === 'MSSymbolMaster') {
        aeArtboard(sketchCode[i]);
      }

    }
  }
  function addFill(r, layer) {
    if (layer.fill !== null) {
      for (var i = layer.fill.length-1; i >= 0; i--) {
        var sketchBlendMode = layer.fill[i].blendMode;
        var aeBlendMode = 1;

        switch (sketchBlendMode) {
          case 1:
            aeBlendMode = 3;
            break;
          case 2:
            aeBlendMode = 4;
            break;
          case 3:
            aeBlendMode = 5;
            break;
          case 4:
            aeBlendMode = 9;
            break;
          case 5:
            aeBlendMode = 10;
            break;
          case 6:
            aeBlendMode = 11;
            break;
          case 7:
            aeBlendMode = 15;
            break;
          case 8:
            aeBlendMode = 16;
            break;
          case 9:
            aeBlendMode = 17;
            break;
          case 10:
            aeBlendMode = 23;
            break;
          case 11:
            aeBlendMode = 24;
            break;
          case 12:
            aeBlendMode = 26;
            break;
          case 13:
            aeBlendMode = 27;
            break;
          case 14:
            aeBlendMode = 28;
            break;
          case 15:
            aeBlendMode = 29;
            break;
          default: aeBlendMode = 1;
        }


        var fill = r(2)(1)(2).addProperty("ADBE Vector Graphic - Fill");
            fill.enabled = layer.fill[i].enabled;
            fill("ADBE Vector Blend Mode").setValue(aeBlendMode);
            fill("ADBE Vector Fill Color").setValue(layer.fill[i].color);
            fill("ADBE Vector Fill Opacity").setValue(layer.fill[i].opacity);
      }
    }
    // fill
    // var fill = r(2)(1)(2).addProperty("ADBE Vector Graphic - Fill");
    //     fill.enabled = (layer.hasFill === 1);
    //     fill("ADBE Vector Fill Color").setValue(layer.fillColor);
    //     fill("ADBE Vector Fill Opacity").setValue(layer.fillOpacity);
		//     fill("ADBE Vector Blend Mode").setValue(15);
  }
  function addStroke(r, layer) {
    if (layer.stroke !== null) {
      for (var i = layer.stroke.length-1; i >= 0; i--) {
        var stroke = r(2)(1)(2).addProperty("ADBE Vector Graphic - Stroke");
            stroke.enabled = layer.stroke[i].enabled;
            stroke("ADBE Vector Stroke Color").setValue(layer.stroke[i].color);
            stroke("ADBE Vector Stroke Opacity").setValue(layer.stroke[i].opacity);
            stroke("ADBE Vector Stroke Width").setValue(layer.stroke[i].width);
            stroke("ADBE Vector Stroke Line Cap").setValue(layer.stroke[i].cap + 1);
            stroke("ADBE Vector Stroke Line Join").setValue(layer.stroke[i].join + 1 );
      }
    }
  }
  function setLayerBlendMode(r, layer) {
    var aeBlendMode = BlendingMode.NORMAL;
    var sketchBlendMode = 0;
    try{ sketchBlendMode = layer.blendMode; } catch(e) {}   // check if the layer has a blendMode

    if (sketchBlendMode !== 0) {

      switch (sketchBlendMode) {
        case 1:
          aeBlendMode = BlendingMode.DARKEN;
          break;
        case 2:
          aeBlendMode = BlendingMode.MULTIPLY;
          break;
        case 3:
          aeBlendMode = BlendingMode.COLOR_BURN;
          break;
        case 4:
          aeBlendMode = BlendingMode.LIGHTEN;
          break;
        case 5:
          aeBlendMode = BlendingMode.SCREEN;
          break;
        case 6:
          aeBlendMode = BlendingMode.ADD;
          break;
        case 7:
          aeBlendMode = BlendingMode.OVERLAY;
          break;
        case 8:
          aeBlendMode = BlendingMode.SOFT_LIGHT;
          break;
        case 9:
          aeBlendMode = BlendingMode.HARD_LIGHT;
          break;
        case 10:
          aeBlendMode = BlendingMode.DIFFERENCE;
          break;
        case 11:
          aeBlendMode = BlendingMode.EXCLUSION;
          break;
        case 12:
          aeBlendMode = BlendingMode.HUE;
          break;
        case 13:
          aeBlendMode = BlendingMode.SATURATION;
          break;
        case 14:
          aeBlendMode = BlendingMode.COLOR;
          break;
        case 15:
          aeBlendMode = BlendingMode.LUMINOSITY;
          break;
        default: aeBlendMode = BlendingMode.NORMAL;
      }
    }
    r.blendingMode = aeBlendMode;
  }
  function addDropShadow(r, layer) {
    try {
    if (layer.shadow !== null) {
      for (var i = layer.shadow.length-1; i >= 0; i--) {

        // math stuff
        var x = layer.shadow[i].position[0]*compMult;
        var y = layer.shadow[i].position[1]*compMult;
        var shadowDistance = Math.sqrt((x * x) + (y * y));                        // pythagorean theorem dude
        var shadowAngle = 90+(Math.atan(y/x) * (180/Math.PI));
            shadowAngle = (isNaN(shadowAngle)) ? 180 : shadowAngle;

        var shadowEffect = r(4).addProperty("ADBE Drop Shadow");
        		shadowEffect("ADBE Drop Shadow-0001").setValue(layer.shadow[i].color);        // color
        		shadowEffect("ADBE Drop Shadow-0002").setValue(layer.shadow[i].color[3]*255); // opacity
        		shadowEffect("ADBE Drop Shadow-0003").setValue(shadowAngle);                  // angle
        		shadowEffect("ADBE Drop Shadow-0004").setValue(shadowDistance);               // distance
        		shadowEffect("ADBE Drop Shadow-0005").setValue(layer.shadow[i].blur*compMult);         // blur
      }
    }
    }catch(e) {}
  }
  // function addDropShadow(r, layer) {
  //   try {
  //   // shadow
  //   if (layer.hasShadow) {
  //     r.selected = true;                                              // select layer in order to create drop shadow on it
  //     app.executeCommand(app.findMenuCommandId("Drop Shadow"));       // create drop shadow
  //     var dropShadow = r("ADBE Layer Styles")("dropShadow/enabled");  // name a var for the layerstyle
  //     r.selected = false;                                             // deselect layer
  //     dropShadow("dropShadow/mode2").setValue(1);
  //     dropShadow("dropShadow/color").setValue(layer.shadowColor);
  //     dropShadow("dropShadow/opacity").setValue(layer.shadowColor[3]*100);
  //     dropShadow("dropShadow/chokeMatte").setValue(layer.shadowSpread);
  //     dropShadow("dropShadow/blur").setValue(layer.shadowBlur);
  //
  //     // math stuff
  //     var x = layer.shadowPos[0];
  //     var y = layer.shadowPos[1];
  //     var shadowDistance = Math.sqrt((x * x) + (y * y));                        // pythagorean theorem dude
  //     var shadowAngle = 180-(Math.atan(y/x) * (180/Math.PI));
  //
  //     shadowAngle = (isNaN(shadowAngle)) ? 180 : shadowAngle;
  //
  //     dropShadow("dropShadow/localLightingAngle").setValue(shadowAngle);
  //     dropShadow("dropShadow/distance").setValue(shadowDistance);
  //   }
  //   }catch(e) {}
  // }      // add single layer style
  function addClipping(layer) {
    if (clippingMask !== null) {
      // alert(clippingMask.index)
      var setMatte = layer("ADBE Effect Parade").addProperty("ADBE Set Matte3");
          // setMatte('ADBE Set Matte3-0001').setValue(clippingMask);
          setMatte('ADBE Set Matte3-0001').setValue(clippingMask);
          clippingMask++;
      // alert(clippingMask.name);

    } else { return; }
  }
  function createStaticShape(path, vertexArray, inTangentsArray, outTangentsArray, closed) {
  	var pathValue = path.value;
  		pathValue.vertices = vertexArray;
  		pathValue.inTangents = inTangentsArray;
  		pathValue.outTangents = outTangentsArray;
  		pathValue.closed = (closed === 1);
  	path.setValue(pathValue);
  }
  function aeArtboard(layer, opt_parent) {

    if (cb_newComp.value) {
      if (ddl_compScale.selection.index === 0) {
        compMult =  3;
      } else if (ddl_compScale.selection.index === 1) {
        compMult =  2;
      } else  {
        compMult =  1;
      }
      thisComp = app.project.items.addComp(layer.name, layer.size[0] * compMult, layer.size[1] * compMult, 1, 60, 60);    // create new comp
      thisComp.bgColor = [layer.backgroundColor[0], layer.backgroundColor[1], layer.backgroundColor[2]];
      thisComp.openInViewer();    // open new comp
    }

    app.activeViewer.setActive();			// set the viewer to active
    if (!setComp()) {return;}         // check if theres a comp selected, stop if not
    compMult = getCompMultiplier(layer.size[0]);
  }
  function aeGroup(layer, opt_parent) {
    var r = thisComp.layers.addShape();
    var groupParent = r;                                                            // set the parentLayer to the group layer
    r.guideLayer = true;
    r.name = '\u25BD ' + layer.name;
    if (opt_parent !== null) {
      r.parent = opt_parent;
      r.moveAfter(opt_parent);
    } else {
      labelColor = (Math.max(labelColor, 1) + 1) % 16;
    }
    r.label = labelColor;
    r.shy = true;
    r.enabled = false;
    clippingMask = (layer.hasClippingMask === 1) ? 2 : null;


    r(2).addProperty("ADBE Vector Group");
    r(2)(1).name = layer.name;
    // rect
    r(2)(1)(2).addProperty("ADBE Vector Shape - Rect");
    r(2)(1)(2)(1)("ADBE Vector Rect Size").setValue([layer.size[0]*compMult, layer.size[1]*compMult]);
    r(2)(1)(2)(1)("ADBE Vector Rect Position").expression = 'thisProperty.propertyGroup(1)(2)/2';
    // r(2)(1)(2)(1)("ADBE Vector Rect Roundness").setValue(layer.roundness);

    // fill
    var fillColor = r(2)(1)(2).addProperty("ADBE Vector Graphic - Fill");
    // r(2)(1)(2)(3).enabled = (layer.hasFill === 1);
    fillColor("ADBE Vector Fill Color").setValue([0,0,0,1]);
    fillColor("ADBE Vector Fill Opacity").setValue(0);

    // stroke
    var strokeColor = r(2)(1)(2).addProperty("ADBE Vector Graphic - Stroke");
    // r(2)(1)(2)(2).enabled = (layer.hasStroke === 1);
    strokeColor("ADBE Vector Stroke Color").setValue([0.298,0.7569,0.9882,1]);
    strokeColor("ADBE Vector Stroke Opacity").setValue(50);
    strokeColor("ADBE Vector Stroke Width").setValue(1);

    // transforms
    r("ADBE Transform Group")("ADBE Position").setValue([layer.position[0]*compMult, layer.position[1]*compMult]);

    // feed the sub layers through the filter
    filterTypes(layer.layers, groupParent);
    clippingMask = null;
  }
  function aeSymbol(layer, opt_parent) {
    createSymbolFolder();
    var symbolPrecomp = createSymbol(layer);
    var r = thisComp.layers.add(symbolPrecomp, symbolPrecomp.duration);
    r.name = '\u21BB ' + r.name;
    r.selected = false;
    r.collapseTransformation = true;

    if (opt_parent !== null) {
      r.parent = opt_parent;
      r.moveAfter(opt_parent);
    } else {
      labelColor = (Math.max(labelColor, 1) + 1) % 16;
    }
    r.label = labelColor;

    addClipping(r);
    addDropShadow(r, layer);
    setLayerBlendMode(r, layer);

    // get the symbol size and compare it to the in-comp size for the scale value
    var scaleVal = [(100 * compMult) * (layer.size[0]/layer.symbolSize[0]), (100 * compMult) * (layer.size[1]/layer.symbolSize[1])];

    r("ADBE Transform Group")("ADBE Anchor Point").setValue([0,0]);
    r("ADBE Transform Group")("ADBE Position").setValue([layer.position[0]*compMult, layer.position[1]*compMult]);
    // r("ADBE Transform Group")("ADBE Scale").setValue([100*compMult, 100*compMult]);
    r("ADBE Transform Group")("ADBE Scale").setValue(scaleVal);
    r("ADBE Transform Group")("ADBE Opacity").setValue(layer.opacity);
  }
  function aeRect(layer, opt_parent) {
    var r = thisComp.layers.addShape();
    r.name = layer.name;
    r.selected = false;
    if (opt_parent !== null) {
      r.parent = opt_parent;
      r.moveAfter(opt_parent);
    } else {
      labelColor = (Math.max(labelColor, 1) + 1) % 16;
    }
    r.label = labelColor;
    r.enabled = layer.isVisible;

    r(2).addProperty("ADBE Vector Group");
    r(2)(1).name = layer.name;

    // // rect
    r(2)(1)(2).addProperty("ADBE Vector Shape - Rect");
    r(2)(1)(2)(1)("ADBE Vector Rect Size").setValue( layer.size );
    r(2)(1)(2)(1)("ADBE Vector Rect Position").expression = 'thisProperty.propertyGroup(1)(2)/2';
    r(2)(1)(2)(1)("ADBE Vector Rect Roundness").setValue(layer.roundness);

    addStroke(r, layer);
    addFill(r, layer);
    addClipping(r);
    addDropShadow(r, layer);
    setLayerBlendMode(r, layer);

    // transforms
    r(2)(1)("ADBE Vector Transform Group")("ADBE Vector Scale").setValue([100*compMult, 100*compMult]);
    r("ADBE Transform Group")("ADBE Position").setValue([layer.position[0]*compMult, layer.position[1]*compMult]);
    r("ADBE Transform Group")("ADBE Opacity").setValue(layer.opacity);
  }
  function aeCompound(layer, opt_parent) {
    var r = thisComp.layers.addShape();
    r.name = layer.name;
    r.selected = false;
    if (opt_parent !== null) {
      r.parent = opt_parent;
      r.moveAfter(opt_parent);
    } else {
      labelColor = (Math.max(labelColor, 1) + 1) % 16;
    }
    r.label = labelColor;
    r.enabled = layer.isVisible;

    r(2).addProperty("ADBE Vector Group");
    r(2)(1).name = layer.name;

    // build sub shapes
    for (var i = 0; i < layer.layers.length; i++) {
      var group = r(2)(1)(2).addProperty("ADBE Vector Group");
          group.name = layer.layers[i].name;
          // var topLeft = [(layer.layers[i].position[0]*compMult) + ((layer.layers[i].size[0]*compMult)/2),
          //                (layer.layers[i].position[1]*compMult) + ((layer.layers[i].size[1]*compMult)/2)];
          var topLeft = layer.layers[i].position + (layer.layers[i].size/2);
          group("ADBE Vector Transform Group")("ADBE Vector Anchor").setValue( topLeft );
          group("ADBE Vector Transform Group")("ADBE Vector Position").setValue( topLeft );
          group("ADBE Vector Transform Group")("ADBE Vector Rotation").setValue(-layer.layers[i].rotation);
      if (layer.layers[i].type === 'MSRectangleShape'){
        var rect = group(2).addProperty("ADBE Vector Shape - Rect");
            rect("ADBE Vector Rect Size").setValue(layer.layers[i].size);
            rect("ADBE Vector Rect Position").setValue(layer.layers[i].position);
            rect("ADBE Vector Rect Position").expression = 'thisProperty.propertyGroup(1)(2)/2 + value';
            rect("ADBE Vector Rect Roundness").setValue(layer.layers[i].roundness);
      }
      if (layer.layers[i].type === 'MSOvalShape'){
        var ellipse = group(2).addProperty("ADBE Vector Shape - Ellipse");
            ellipse("ADBE Vector Ellipse Size").setValue(layer.layers[i].size);
            ellipse("ADBE Vector Ellipse Position").setValue(layer.layers[i].position);
            ellipse("ADBE Vector Ellipse Position").expression = 'thisProperty.propertyGroup(1)(2)/2 + value';
      }
      if (layer.layers[i].type === 'MSShapePathLayer'){

        group("ADBE Vector Transform Group")("ADBE Vector Anchor").setValue([0,0]);
        group("ADBE Vector Transform Group")("ADBE Vector Position").setValue(layer.layers[i].position);
        // group("ADBE Vector Transform Group")("ADBE Vector Position").setValue([layer.layers[i].position[0]*compMult, layer.layers[i].position[1]*compMult]);
        var vect = group(2).addProperty("ADBE Vector Shape - Group");
          var path = vect.property("ADBE Vector Shape");
          var vertices = layer.layers[i].path.points;
          var inTangents = layer.layers[i].path.inTangents;
          var outTangents = layer.layers[i].path.outTangents;
          var shapeClosed = layer.layers[i].path.closed;
          createStaticShape(path, vertices, inTangents, outTangents, shapeClosed);


          // round corners
          if (layer.layers[i].roundness > 0) {
            group(2).addProperty("ADBE Vector Filter - RC");
            group(2)("ADBE Vector Filter - RC")("ADBE Vector RoundCorner Radius").setValue(layer.layers[i].roundness);
          }
      }
      // merge path
      if (i > 0) {    // only add after the second shape
        addMerge(layer.layers[i].booleanOperation);
      }
    }

    addStroke(r, layer);
    addFill(r, layer);
    addClipping(r);
    addDropShadow(r, layer);
    setLayerBlendMode(r, layer);

    // transforms
    r(2)(1)("ADBE Vector Transform Group")("ADBE Vector Scale").setValue([100*compMult, 100*compMult]);
    r("ADBE Transform Group")("ADBE Position").setValue([layer.position[0]*compMult, layer.position[1]*compMult]);
    r("ADBE Transform Group")("ADBE Opacity").setValue(layer.opacity);

    function addMerge(bool) {
      // if (bool > 0) {
        var merge = r(2)(1)(2).addProperty("ADBE Vector Filter - Merge");
            merge("ADBE Vector Merge Type").setValue(bool+2);
      // }
    }
  }
  function aeEllipse(layer, opt_parent) {
    var r = thisComp.layers.addShape();
    r.name = layer.name;
    r.selected = false;
    if (opt_parent !== null) {
      r.parent = opt_parent;
      r.moveAfter(opt_parent);
    } else {
      labelColor = (Math.max(labelColor, 1) + 1) % 16;
    }
    r.label = labelColor;
    r.enabled = layer.isVisible;

    r(2).addProperty("ADBE Vector Group");
    r(2)(1).name = layer.name;
    // rect
    r(2)(1)(2).addProperty("ADBE Vector Shape - Ellipse");
    r(2)(1)(2)(1)("ADBE Vector Ellipse Size").setValue(layer.size);
    r(2)(1)(2)(1)("ADBE Vector Ellipse Position").expression = 'thisProperty.propertyGroup(1)(2)/2';

    addStroke(r, layer);
    addFill(r, layer);
    addClipping(r);
    addDropShadow(r, layer);
    setLayerBlendMode(r, layer);

    // transforms
    r(2)(1)("ADBE Vector Transform Group")("ADBE Vector Scale").setValue([100*compMult, 100*compMult]);
    r("ADBE Transform Group")("ADBE Position").setValue([layer.position[0]*compMult, layer.position[1]*compMult]);
    r("ADBE Transform Group")("ADBE Opacity").setValue(layer.opacity);
  }
  function aePath(layer, opt_parent) {
    var r = thisComp.layers.addShape();
    r.name = layer.name;
    r.selected = false;
    if (opt_parent !== null) {
      r.parent = opt_parent;
      r.moveAfter(opt_parent);
    } else {
      labelColor = (Math.max(labelColor, 1) + 1) % 16;
    }
    r.label = labelColor;
    r.enabled = layer.isVisible;

    var group = r(2).addProperty("ADBE Vector Group");
    group(2).addProperty("ADBE Vector Shape - Group");
    var path = group(2)(1).property("ADBE Vector Shape");
    var vertices = layer.path.points;
		var inTangents = layer.path.inTangents;
		var outTangents = layer.path.outTangents;
		var shapeClosed = layer.path.closed;
		createStaticShape(path, vertices, inTangents, outTangents, shapeClosed);

    group("ADBE Vector Transform Group")("ADBE Vector Scale").setValue([100*compMult, 100*compMult]);

    // round corners
    if (layer.roundness > 0) {
      var round = group(2).addProperty("ADBE Vector Filter - RC");
          round("ADBE Vector RoundCorner Radius").setValue(layer.roundness);
    }

    addStroke(r, layer);
    addFill(r, layer);
    addClipping(r);
    addDropShadow(r, layer);
    setLayerBlendMode(r, layer);

    // transforms
    r("ADBE Transform Group")("ADBE Position").setValue([layer.position[0]*compMult, layer.position[1]*compMult]);
    r("ADBE Transform Group")("ADBE Opacity").setValue(layer.opacity);
  }
  function aeText(layer, opt_parent) {
    try {
    var r = thisComp.layers.addBoxText([layer.size[0], layer.size[1]], '');
    r.name = layer.name;

    r.selected = false;
    if (opt_parent !== null) {
      r.parent = opt_parent;
      r.moveAfter(opt_parent);
    } else {
      labelColor = (Math.max(labelColor, 1) + 1) % 16;
    }
    r.label = labelColor;
    r.enabled = layer.isVisible;

    var textProp = r("ADBE Text Properties")("ADBE Text Document");

    var textDoc = textProp.value;
    textDoc.resetCharStyle();
    textDoc.resetParagraphStyle();

    textDoc.font = layer.fontName;
    textDoc.fontSize = layer.fontSize;

    //// fill color
    var fill = layer.textColor;
    textDoc.applyFill = (layer.hasFill === 1);
    textDoc.fillColor = [fill[0], fill[1], fill[2]];

    //// stroke color
    if (layer.stroke !== null) {
      var stroke = layer.stroke[0];
      textDoc.applyStroke = (stroke.enabled === 1);
      textDoc.strokeColor = [stroke.color[0], stroke.color[1], stroke.color[2]];
      textDoc.strokeWidth = (stroke.width > 0) ? stroke.width : 0;

      if (stroke.opacity < 100) {
        // try {
        //   var textOpacity = r("ADBE Text Properties")("ADBE Text Animators")("Text Opacity");
        // } catch (e) {
          var textOpacity = r("ADBE Text Properties")(4).addProperty("ADBE Text Animator");
            textOpacity.name = 'Text Opacity';
          // }
  		    var strokeOpacity = textOpacity("ADBE Text Animator Properties").addProperty("ADBE Text Stroke Opacity");
              strokeOpacity.setValue(stroke.opacity);
      }
    }

    textFill();

    //// text color opacity
    if (fill[3] < 1) {
      var textOpacity = r("ADBE Text Properties")(4).addProperty("ADBE Text Animator");
          textOpacity.name = 'Text Opacity';
      if (fill[3] < 1) {
  		    var fillOpacity = textOpacity("ADBE Text Animator Properties").addProperty("ADBE Text Fill Opacity");
              fillOpacity.setValue(fill[3] * 100);
      }

  		// r("ADBE Text Properties")(4)(1)(1).addProperty("ADBE Text Selector");
    }

    //// text metrics
    textDoc.tracking = Math.floor(layer.tracking);

    //// text transforms


    //// paragraph
    textDoc.justification = paragraphJustification(layer.justification);
    textDoc.boxTextSize = [layer.size[0] * 1.05, layer.size[1] * 1.1];     // resize the text box a little taller

    //// line height
    var autoLineHeight = Math.round(layer.fontSize * 1.202);
    var manualLineHeight = layer.lineHeight - autoLineHeight;
    var lineHeight = r("ADBE Text Properties")(4).addProperty("ADBE Text Animator");
        lineHeight.name = 'Line Height';
    		lineHeight("ADBE Text Animator Properties").addProperty("ADBE Text Line Spacing");
    		lineHeight(1).addProperty("ADBE Text Selector");
    		// lineHeight(2).property("ADBE Text Line Spacing").setValue([0,7]);
    		lineHeight(2).property("ADBE Text Line Spacing").setValue([0,manualLineHeight]);


    textProp.setValue(textDoc);           // set text properties
    textProp.setValue(layer.stringVal);   // set text string

    addClipping(r);
    addDropShadow(r, layer);
    setLayerBlendMode(r, layer);

    // // transforms
    // r("ADBE Transform Group")("ADBE Anchor Point").setValue([Math.round(r.sourceRectAtTime(0,false).width * -0.61),Math.floor(r.sourceRectAtTime(0,false).height * -1.125)]);   // reposition anchor to the top left
    // r("ADBE Transform Group")("ADBE Anchor Point").setValue([Math.round(r.sourceRectAtTime(0,false).width * -0.875),Math.floor(r.sourceRectAtTime(0,false).height * -1.125)]);   // reposition anchor to the top left
    // r("ADBE Transform Group")("ADBE Anchor Point").setValue([Math.floor(r.sourceRectAtTime(0,false).width/-2.03),Math.floor(r.sourceRectAtTime(0,false).height/-1.45)]);   // reposition anchor to the top left
    r("ADBE Transform Group")("ADBE Anchor Point").setValue([Math.floor(layer.size[0] * -0.5), Math.round((r.sourceRectAtTime(0,false).height + layer.fontSize)*-0.49)]);   // ******* WORKS ********reposition anchor to the top left
    // r("ADBE Transform Group")("ADBE Anchor Point").setValue([Math.floor(layer.size[0] * -0.5), layer.size[1] * -0.59]);   // ******* WORKS ********reposition anchor to the top left
    // r("ADBE Transform Group")("ADBE Anchor Point").setValue([layer.size[0]/-2, Math.round(layer.size[1]/-1.95)]);   // reposition anchor to the top left
    r("ADBE Transform Group")("ADBE Scale").setValue([100*compMult, 100*compMult]);
    r("ADBE Transform Group")("ADBE Position").setValue([layer.position[0]*compMult, layer.position[1]*compMult]);
    r("ADBE Transform Group")("ADBE Opacity").setValue(layer.opacity);
    } catch(e) {
      alert(e.toString() + "\nError on line: " + e.line.toString());
    }
    function textFill() {
      if (layer.fill !== null) {

        for (var i = 0; i < layer.fill.length; i++) {
          var sketchBlendMode = layer.fill[i].blendMode;
          var aeBlendMode = 1;

          // switch (sketchBlendMode) {
          //   case 1:
          //     aeBlendMode = 3;
          //     break;
          //   case 2:
          //     aeBlendMode = 4;
          //     break;
          //   case 3:
          //     aeBlendMode = 5;
          //     break;
          //   case 4:
          //     aeBlendMode = 9;
          //     break;
          //   case 5:
          //     aeBlendMode = 10;
          //     break;
          //   case 6:
          //     aeBlendMode = 11;
          //     break;
          //   case 7:
          //     aeBlendMode = 15;
          //     break;
          //   case 8:
          //     aeBlendMode = 16;
          //     break;
          //   case 9:
          //     aeBlendMode = 17;
          //     break;
          //   case 10:
          //     aeBlendMode = 23;
          //     break;
          //   case 11:
          //     aeBlendMode = 24;
          //     break;
          //   case 12:
          //     aeBlendMode = 26;
          //     break;
          //   case 13:
          //     aeBlendMode = 27;
          //     break;
          //   case 14:
          //     aeBlendMode = 28;
          //     break;
          //   case 15:
          //     aeBlendMode = 29;
          //     break;
          //   default: aeBlendMode = 1;
          // }


          var textFill = r("ADBE Text Properties")(4).addProperty("ADBE Text Animator");
              textFill.name = 'Text Fill ' + (i + 1);
  		        textFill("ADBE Text Animator Properties").addProperty("ADBE Text Fill Color");
  		        textFill("ADBE Text Animator Properties")("ADBE Text Fill Color").setValue(layer.fill[i].color);
  		        textFill("ADBE Text Animator Properties").addProperty("ADBE Text Fill Opacity");
  		        textFill("ADBE Text Animator Properties")("ADBE Text Fill Opacity").setValue(layer.fill[i].opacity);
        }
      }
    }
    function paragraphJustification(num) {
      var paraStyle;

      switch (num) {
        case 1:
          paraStyle = ParagraphJustification.RIGHT_JUSTIFY;
          break;
        case 2:
          paraStyle = ParagraphJustification.CENTER_JUSTIFY;
          break;
        case 3:
          paraStyle = ParagraphJustification.FULL_JUSTIFY_LASTLINE_FULL;
          break;
        default: paraStyle = ParagraphJustification.LEFT_JUSTIFY;
      }
      // var paraStyle = [
      //     ParagraphJustification.LEFT_JUSTIFY,    //0   &   4
      //     ParagraphJustification.RIGHT_JUSTIFY,   //1
      //     ParagraphJustification.CENTER_JUSTIFY,  //2
      //     ParagraphJustification.FULL_JUSTIFY_LASTLINE_LEFT,
      //     ParagraphJustification.FULL_JUSTIFY_LASTLINE_RIGHT,
      //     ParagraphJustification.FULL_JUSTIFY_LASTLINE_CENTER,
      //     ParagraphJustification.FULL_JUSTIFY_LASTLINE_FULL     //3
      // ];
      return paraStyle;
    }
  }
  function aeImage(layer, opt_parent) {
    // alert(layer.fileName)
    createImageFolder();
    // import images
    var filePath = (relativePath) ? inputFile.path : layer.path;   // check if its a relative path
    var bmpImage = getItem(layer.fileName, FileSource, imageFolder);
    if (bmpImage === null) {
  		// var bitmapCopy2png_path = "~/Desktop/Bitmap Copy 2.png";
  		var bmpFile = new ImportOptions(new File(filePath + '/' + layer.fileName));
  		bmpImage = app.project.importFile(bmpFile);
      bmpImage.parentFolder = imageFolder;
  			bmpImage.selected = false;
  	}

    var r = thisComp.layers.add(bmpImage);
    r.selected = false;
    if (opt_parent !== null) {
      r.parent = opt_parent;
      r.moveAfter(opt_parent);
    } else {
      labelColor = (Math.max(labelColor, 1) + 1) % 16;
    }

    // addClipping(r);
    addDropShadow(r, layer);
    setLayerBlendMode(r, layer);

    // transforms
    r("ADBE Transform Group")("ADBE Position").setValue([layer.position[0]*compMult, layer.position[1]*compMult]);
    r("ADBE Transform Group")("ADBE Anchor Point").setValue([0,0]);
    r("ADBE Transform Group")("ADBE Scale").setValue([(100/layer.scale)*compMult, (100/layer.scale)*compMult]);

    // transform effect
    // var transform = r("ADBE Effect Parade").addProperty("ADBE Geometry2");
    //     transform("ADBE Geometry2-0001").setValue([0,0]);
    //     transform("ADBE Geometry2-0002").setValue(layer.position);
    //     transform("ADBE Geometry2-0003").setValue(100/layer.scale);

    function getItem(itemName, itemInstanceName, locationObject) {
    	if (locationObject.numItems > 0) {
    		for (var i = 1; i <= locationObject.numItems; i ++) {
    			var curItem = locationObject.item(i);
    			if (curItem.name === itemName) {
    				if (curItem instanceof itemInstanceName || (curItem.mainSource !== "undefined" && curItem.mainSource instanceof itemInstanceName)) {
    					return curItem;
    				}
    			}
    		}
    	}
    	return null;
    }
  }

  // function aeText(layer, opt_parent) {
  //   try {
  //   var r = thisComp.layers.addBoxText([layer.size[0], layer.size[1]], '');
  //   r.name = layer.name;
  //
  //   r.selected = false;
  //   if (opt_parent !== null) {
  //     r.parent = opt_parent;
  //     r.moveAfter(opt_parent);
  //   } else {
  //     labelColor = (Math.max(labelColor, 1) + 1) % 16;
  //   }
  //   r.label = labelColor;
  //
  //   var textProp = r("ADBE Text Properties")("ADBE Text Document");
  //
  //   var textDoc = textProp.value;
  //   textDoc.resetCharStyle();
  //   textDoc.resetParagraphStyle();
  //
  //   textDoc.font = layer.fontName;
  //   textDoc.fontSize = layer.fontSize;
  //
  //   //// fill color
  //   var fill = layer.fillColor;
  //   textDoc.applyFill = (layer.hasFill === 1);
  //   textDoc.fillColor = [fill[0], fill[1], fill[2]];
  //
  //   //// stroke color
  //   var stroke = layer.strokeColor;
  //   textDoc.applyStroke = (layer.hasStroke === 1);
  //   textDoc.strokeColor = [stroke[0], stroke[1], stroke[2]];
  //   textDoc.strokeWidth = (layer.strokeWeight > 0) ? layer.strokeWeight : 0;
  //
  //   //// text color opacity
  //   if (fill[3] < 1 || stroke[3] < 1) {
  //     var textOpacity = r("ADBE Text Properties")(4).addProperty("ADBE Text Animator");
  //         textOpacity.name = 'Text Opacity';
  //     if (fill[3] < 1) {
  // 		    var fillOpacity = textOpacity("ADBE Text Animator Properties").addProperty("ADBE Text Fill Opacity");
  //             fillOpacity.setValue(fill[3] * 100);
  //     }
  //     if (fill[3] < 1) {
  // 		    var strokeOpacity = textOpacity("ADBE Text Animator Properties").addProperty("ADBE Text Stroke Opacity");
  //             strokeOpacity.setValue(stroke[3] * 100);
  //     }
  // 		// r("ADBE Text Properties")(4)(1)(1).addProperty("ADBE Text Selector");
  //   }
  //
  //   //// text metrics
  //   textDoc.tracking = Math.floor(layer.tracking*10);
  //
  //   //// text transforms
  //
  //
  //   //// paragraph
  //   textDoc.justification = paragraphJustification(layer.justification);
  //   textDoc.boxTextSize = [layer.size[0] * 1.05, layer.size[1] * 1.1];     // resize the text box a little taller
  //
  //   //// line height
  //   var autoLineHeight = Math.floor(layer.fontSize * 1.202);
  //   var manualLineHeight = layer.lineHeight - autoLineHeight;
  //   var lineHeight = r("ADBE Text Properties")(4).addProperty("ADBE Text Animator");
  //       lineHeight.name = 'Line Height';
  //   		lineHeight("ADBE Text Animator Properties").addProperty("ADBE Text Line Spacing");
  //   		lineHeight(1).addProperty("ADBE Text Selector");
  //   		lineHeight(2).property("ADBE Text Line Spacing").setValue([0,manualLineHeight]);
  //
  //
  //   textProp.setValue(textDoc);           // set text properties
  //   textProp.setValue(layer.stringVal);   // set text string
  //
  //   addClipping(r);
  //   addDropShadow(r, layer);
  //
  //   // // transforms
  //   r("ADBE Transform Group")("ADBE Anchor Point").setValue([Math.floor(r.sourceRectAtTime(0,false).width/-2.03),Math.floor(r.sourceRectAtTime(0,false).height/-1.45)]);   // reposition anchor to the top left
  //   // r("ADBE Transform Group")("ADBE Anchor Point").setValue([layer.size[0]/-2, Math.round(layer.size[1]/-1.95)]);   // reposition anchor to the top left
  //   r("ADBE Transform Group")("ADBE Position").setValue(layer.position);
  //   } catch(e) {
  //     alert(e.toString() + "\nError on line: " + e.line.toString());
  //   }
  //
  //   function paragraphJustification(num) {
  //     var paraStyle = [
  //         ParagraphJustification.LEFT_JUSTIFY,
  //         ParagraphJustification.RIGHT_JUSTIFY,
  //         ParagraphJustification.CENTER_JUSTIFY,
  //         ParagraphJustification.FULL_JUSTIFY_LASTLINE_LEFT,
  //         ParagraphJustification.FULL_JUSTIFY_LASTLINE_RIGHT,
  //         ParagraphJustification.FULL_JUSTIFY_LASTLINE_CENTER,
  //         ParagraphJustification.FULL_JUSTIFY_LASTLINE_FULL
  //     ];
  //     return paraStyle[num];
  //   }
  // }

  function listObj(obj) {     // list all properties in an object
    var propList = [];

    for (var prop in obj) {
      if (obj.hasOwnProperty(prop)) {
        try {
          propList.push(prop + ' -> ' + obj[prop]);
        } catch(e) {propList.push(prop + ' -> OBJECT');}

      }
    }
    alert('Properties:\n' + propList.join('\n'));
  }

  // _______ UI SETUP _______
  // if the script is a Panel, (launched from the 'Window' menu), use it,
  // else (launched via 'File/Scripts/Run script...') create a new window
  // store it in the variable mainPalette
  var mainPalette = thisObj instanceof Panel ? thisObj : new Window('palette',scriptName,undefined, {resizeable:true});

  //stop if there's no window
  if (mainPalette === null) return;

  // set margins and alignment
  mainPalette.alignChildren = ['fill','fill'];
  mainPalette.margins = 5;
  mainPalette.spacing = 2;
  //__________________________



  // ============ ADD UI CONTENT HERE =================
  var content = mainPalette.add('group');
  content.maximumSize.width = 186;
  content.alignChildren = ['fill','top'];
  content.orientation = 'column';
  content.margins = 0;
  content.spacing = 8;


  var grp_entryButtons = content.add('group');
      grp_entryButtons.minimumSize.height = 50;
      grp_entryButtons.maximumSize.height = 50;
      grp_entryButtons.orientation = 'row';
      grp_entryButtons.alignChildren = ['fill', 'fill'];
  var btn_pasteSketch = vecButton(grp_entryButtons, icons.paste, '#F44336', [88,50]);
      btn_pasteSketch.helpTip = 'Paste layer data from clipboard';
  var btn_openSketch = vecButton(grp_entryButtons, icons.open, '#0097A7', [88,50]);
      btn_openSketch.helpTip = 'Open layer data from .sktchae file';

  var grp_options = content.add('group');
      grp_options.orientation = 'row';
      grp_options.alignChildren = ['fill', 'top'];

  var cb_newComp = grp_options.add('checkbox', undefined, 'New Comp');
      cb_newComp.value = false;
  var ddl_compScale = grp_options.add('dropdownlist', undefined, ['3x', '2x', '1x']);
      ddl_compScale.selection = 0;
      ddl_compScale.visible = false;

  var btn_toggleGuides = content.add('button', undefined, 'Group Visibility');
      btn_toggleGuides.minimumSize.height = 30;
      btn_toggleGuides.maximumSize.height = 30;

  btn_pasteSketch.onClick = function() {
    var relativePath = false;
    compMult = 1;                   // initialize back to 1x
    var w = new Window ("dialog", 'Import layers from Sketch');
        w.spacing = 0;
        w.margins = 0;
      var content = w.add('group', undefined, '');
          content.alignChildren = ['fill','fill'];
          content.orientation = 'column';
          content.alignment = ['left', 'top'];
          content.margins = 16;
          content.spacing = 8;

          // content.add('statictext', undefined, 'Get ')

          var et_codeField = content.add('edittext', [0,0,224,32], 'Paste Sketch code');    // Hose name field
              et_codeField.active = true;                                    // put the cursor in this field
          var btn_build = buttonColor(content, '#F44336', 'Build Layers');


      if (w.show() === 1) {
        buildLayers(et_codeField.text);
      }
  };
  btn_openSketch.onClick = function() {
    var relativePath = true;
    inputFile = File.openDialog('Open a ' + scriptName + ' file', undefined, false);
    if (inputFile.toString().search(/\.sktchae/) === -1) { alert('Gotta select a valid file.'); return;}

    // open, read string, close file
    inputFile.open( 'r' );
    var inputString = inputFile.read();
    inputFile.close();

    // build everything from file
    buildLayers(inputString);
  };
  btn_toggleGuides.onClick = function() {
    var guideViz;
    setComp();
    app.beginUndoGroup('Toggle Guide Layer Visibility');
    for (var i = 1; i <= thisComp.layers.length; i++) {   // loop through all layers
      var currentLayer = thisComp.layer(i);
      if(currentLayer.guideLayer === true) {              // find the visibility of the first guideLayer
        guideViz = currentLayer.enabled;
        continue;
      }
    }
    for (var j = 1; j <= thisComp.layers.length; j++) {   // loop through all layers
      var currentLayer = thisComp.layer(j);
      if(currentLayer.guideLayer === true) {              // check if its a guideLayer
        currentLayer.enabled = !guideViz;     // set the the inverse of the first found guideLayer
      }
    }
    app.endUndoGroup();
  };
  cb_newComp.onClick = function() {
    if (cb_newComp.value) {
      ddl_compScale.visible = true;
    } else {
      ddl_compScale.visible = false;
    }
    // mainPalette.layout.layout(true);
    // mainPalette.show();
  }         // show or hide comp scaling

  function clearInput() {
    // if (et_codeField.text === defaultBoxText ) {
      et_codeField.text = '';
    // }
  }
  function defaultInput() {
    if (et_codeField.text === '') {
        et_codeField.text = defaultBoxText;
    }
  }


  // ==================================================

  //__________ SHOW UI ___________
  {
    // Set layout, and resize it on resize of the Panel/Window
    mainPalette.layout.layout(true);
    mainPalette.layout.resize();
    mainPalette.onResizing = mainPalette.onResize = function () {mainPalette.layout.resize();};
    //if the script is not a Panel (launched from File/Scripts/Run script...) we need to show it
    if (!(mainPalette instanceof Panel)) mainPalette.show();
  }
  //______________________________
})(this);
