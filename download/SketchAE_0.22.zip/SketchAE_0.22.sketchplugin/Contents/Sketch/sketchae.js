var app = NSApplication.sharedApplication();
var doc;
var pages;
var currentPage_index;
var sketchFile;
var folderPath;
var hasArtboard;
var imageCount;
var imageInc;

var exportCopy = function(context) {
  sketchFile = context;
  doc = context.document;
  pages = doc.pages();            // list all pages
  currentPage_index = pages.indexOfObject(doc.currentPage());
  var selection = context.selection;
  var selectedLayerInfo = [];     // array to store all the selected layer info
  folderPath = null;
  hasArtboard = false;            // reset the state of having a stored artboard to false
  imageInc = 0;                   // set image inc back to 0

  // check if artboard is selected
  if (selection.firstObject().class() == 'MSArtboardGroup' || selection.firstObject().class() == 'MSSymbolMaster') {
    selection = selection.firstObject().layers();       // add children
  }

  // selectedLayerInfo = storeArtboard();                  // add artboard data first
  selectedLayerInfo = filterTypes(selection);
  // save_text(selectedLayerInfo, '/Users/adamplouff/Desktop/export.sktchae');
  copy_text(selectedLayerInfo);

  doc.setCurrentPage(pages[currentPage_index]);                    // switch back to current page
  doc.showMessage("Copied " + selection.count() + " layers to clipboard");
};
var exportSave = function(context) {
  sketchFile = context;
  doc = context.document;
  pages = doc.pages();            // list all pages
  var selection = context.selection;
  var selectedLayerInfo = [];     // array to store all the selected layer info
  folderPath = null;              // reset folder path
  hasArtboard = false;            // reset the state of having a stored artboard to false
  imageInc = 0;                   // set image inc back to 0

  // check if artboard is selected
  if (selection.firstObject().class() == 'MSArtboardGroup' || selection.firstObject().class() == 'MSSymbolMaster') {
    selection = selection.firstObject().layers();       // add children
  }
  getFolderPath();

  //manually override save location
  // savePath = folderPath;
  // folderPath = 'null';

  // check if artboard is selected
  if (selection.firstObject().class() == 'MSArtboardGroup' || selection.firstObject().class() == 'MSSymbolMaster') {
    selection = selection.firstObject().layers();       // add children
  }

  selectedLayerInfo = filterTypes(selection);
  // folderPath = savePath;
  save_text(selectedLayerInfo, folderPath + '_SketchExport.sktchae');
  // copy_text(selectedLayerInfo);

  doc.setCurrentPage(pages[currentPage_index]);                    // switch back to current page
  doc.showMessage("Saved " + selection.count() + " layers to " + savePath);

};
var exportImages = function(context) {
  doc = context.document;
  var selection = context.selection;
  imageCount = 0;
  // var selectedLayerInfo = [];     // array to store all the selected layer info
  folderPath = null;              // reset folder path
  getFolderPath();

  // check if artboard is selected
  // if (selection.firstObject().class() == 'MSArtboardGroup') {
  //   selection = selection.firstObject().layers();       // add children
  // }

  saveImageFiles(selection);
  // save_text(selectedLayerInfo, savePath + '_SketchExport.sktchae');

  doc.showMessage("Saved " + imageCount + " images to " + folderPath);

};


//// Functions
function alert(text, opt_headline) {
  var headline = (opt_headline !== undefined) ? opt_headline : 'Alert';
  NSApplication.sharedApplication().displayDialog_withTitle(text.toString(), headline);
}
function copy_text(txt){
  var pasteBoard = NSPasteboard.generalPasteboard();
      pasteBoard.clearContents();
      [pasteBoard declareTypes:[NSArray arrayWithObject:NSPasteboardTypeString] owner:nil];
      [pasteBoard setString:txt forType:NSPasteboardTypeString];
}
function save_text(text, filePath)){
  var t = [NSString stringWithFormat:@"%@", text],
    f = [NSString stringWithFormat:@"%@", filePath];

    [t writeToFile:f atomically:true encoding:NSUTF8StringEncoding error:nil]
}
function getFolderPath() {
  if (folderPath == null) {
    var saveWindow = NSOpenPanel.openPanel()
    saveWindow.setCanCreateDirectories(true)
    saveWindow.setCanChooseDirectories(true)
    saveWindow.setCanChooseFiles(false);

    saveWindow.setPrompt("Select");
    saveWindow.setMessage("Location to save files");
    saveWindow.runModal();
    folderPath = saveWindow.URLs().objectAtIndex(0).toString();
    folderPath = folderPath.replace('file://', '');                    // remove the file://
  }
}

function objString(obj) {
  //// add each object value to the string
  var selString = '{';
  for (var prop in obj) {
    selString += (String('\"' + prop + '\"' + ': ' + obj[prop] + ',\n'));
  }
  selString += '}';
  //
  //// remove commas between {,}
  // selString = selString.replace('{,', '{');
  selString = selString.replace(',\n}', '}');

  return selString;
}
function filterTypes(selection) {
  var selectedLayerInfo = [];     // array to store all the selected layer info
  if (!hasArtboard) {selectedLayerInfo.push(storeArtboard());}                  // add artboard data first if not artboard data is stored

  var selCount = selection.count();
  for (var i = 0; i < selCount; i++) {  // loop through all selected layers
    var sel = selection[i];
    //// check the type of class
    if (sel.class() == 'MSShapeGroup' && sel.layers().length > 1) {             // is a compound shape
      selectedLayerInfo.push(storeCompoundShape(sel));
    }
    if (sel.class() == 'MSShapeGroup' && sel.layers().length < 2) {             // is a simple shape
      // check if the fill is image based
      if (sel.style().fills().length > 0 && sel.style().fills().firstObject().fillType() > 0) {
        // alert(sel.name())
        selectedLayerInfo.push(storeImgFill(sel));
      } else {
        selectedLayerInfo.push(storeShape(sel));
      }
    }
    if (sel.class() == 'MSRectangleShape' || sel.class() == 'MSShapePathLayer') {                                    // base rectangle within compound
      selectedLayerInfo.push(storeRect(sel));
    }
    if (sel.class() == 'MSOvalShape') {                                         // base oval within compound
      selectedLayerInfo.push(storeOval(sel));
    }
    if (sel.class() == 'MSLayerGroup') {
      selectedLayerInfo.push(storeGroup(sel));
    }
    if (sel.class() == 'MSTextLayer') {
      selectedLayerInfo.push(storeText(sel));
    }
    if (sel.class() == 'MSBitmapLayer') {
      selectedLayerInfo.push(storeImg(sel));
    }
    if (sel.class() == 'MSSymbolInstance') {
      selectedLayerInfo.push(storeSymbol(sel));
    }
  }
  return  '[' + selectedLayerInfo.toString() + ']';
}
function saveImageFiles(selection) {
  var selectedLayerInfo = [];     // array to store all the selected layer info
  if (!hasArtboard) {selectedLayerInfo.push(storeArtboard());}                  // add artboard data first if not artboard data is stored

  var selCount = selection.count();
  for (var i = 0; i < selCount; i++) {  // loop through all selected layers
    var sel = selection[i];
    //// check the type of class
    // if (sel.class() == 'MSShapeGroup' && sel.layers().length > 1) {             // is a compound shape
    //   selectedLayerInfo.push(storeCompoundShape(sel));
    // }
    if (sel.class() == 'MSShapeGroup' && sel.layers().length < 2) {             // is a simple shape
      // check if the fill is image based
      if (sel.style().fills().length > 0 && sel.style().fills().firstObject().fillType() > 0) {
        // alert(sel.name())
        selectedLayerInfo.push(storeImgFill(sel));
        imageCount++;         // add 1 to imageCount everytime an image is saved
      }
      // else {
      //   selectedLayerInfo.push(storeShape(sel));
      // }
    }
    // if (sel.class() == 'MSRectangleShape' || sel.class() == 'MSShapePathLayer') {                                    // base rectangle within compound
    //   selectedLayerInfo.push(storeRect(sel));
    // }
    // if (sel.class() == 'MSOvalShape') {                                         // base oval within compound
    //   selectedLayerInfo.push(storeOval(sel));
    // }
    if (sel.class() == 'MSLayerGroup') {
      selectedLayerInfo.push(storeGroup(sel));
    }
    // if (sel.class() == 'MSTextLayer') {
    //   selectedLayerInfo.push(storeText(sel));
    // }
    if (sel.class() == 'MSBitmapLayer') {
      selectedLayerInfo.push(storeImg(sel));
      imageCount++;         // add 1 to imageCount everytime an image is saved
    }
    // if (sel.class() == 'MSSymbolInstance') {
    //   selectedLayerInfo.push(storeSymbol(sel));
    // }
  }
  return  '[' + selectedLayerInfo.toString() + ']';
}
function storeArtboard() {
  hasArtboard = true;
  var artboard = doc.findCurrentArtboardGroup();

  var selData =  {type: '\"' + artboard.class() + '\"',
                  name: '\"' + artboard.name() + '\"',
                  backgroundColor: '[' + sketchColorToArray(artboard.backgroundColor()) + ']',
                  size: '[' + artboard.frame().width() + ', ' + artboard.frame().height() + ']'
                  // isVisible: sel.isVisible(),
                  // size: '[' + round100(f.width()) + ', ' + round100(f.height())] + ']',
                  // // path: '[' + shapePoints.points + ']',
                  // // inTangents: '[' + shapePoints.inTangents + ']',
                  // // outTangents: '[' + shapePoints.outTangents + ']',
                  // // pathClosed: shapePoints.closed,
                  // path: getPathGroup(sel.layers()),
                  // roundness: cornerRoundness,
                  // position: '[' + [round100(f.x()), round100(f.y())] + ']',
                  // opacity: Math.round(sel.style().contextSettings().opacity() * 100),
                  // fill: getFills(sel),
                  // stroke: getStrokes(sel),
                  // shadow: getShadows(sel),
                  // blendMode: sel.style().contextSettings().blendMode()
                  };

  return objString(selData);
}
function storeShape(sel) {
  // alert(sel.name() + ' :: This is a shape!!!!');
  var f = sel.frame();
  // var shapePoints = shapeToPointArray(sel);
  var cornerRoundness = 0;
      try {cornerRoundness = sel.layers().firstObject().cornerRadiusFloat();} catch(e) {}

  var shapeType = (sel.layers()[0].edited()) ? 'MSShapePathLayer' : sel.layers().firstObject().class();
  var selData =  {type: '\"' + shapeType + '\"',
                  name: '\"' + sel.name() + '\"',
                  isVisible: sel.isVisible(),
                  size: '[' + round100(f.width()) + ', ' + round100(f.height())] + ']',
                  // path: '[' + shapePoints.points + ']',
                  // inTangents: '[' + shapePoints.inTangents + ']',
                  // outTangents: '[' + shapePoints.outTangents + ']',
                  // pathClosed: shapePoints.closed,
                  path: getPathGroup(sel.layers()),
                  roundness: cornerRoundness,
                  position: '[' + [round100(f.x()), round100(f.y())] + ']',
                  opacity: Math.round(sel.style().contextSettings().opacity() * 100),
                  fill: getFills(sel),
                  stroke: getStrokes(sel),
                  shadow: getShadows(sel),
                  blendMode: sel.style().contextSettings().blendMode()
                  };


  return objString(selData);
}
function storeRect(sel) {
  // alert(sel.name() + ' :: This is a rect!!!!');
  var f = sel.frame();
  // var shapePoints = layerToPointArray(sel);
  var cornerRoundness = 0;
      try {cornerRoundness = sel.cornerRadiusFloat();} catch(e) {}
      var shapeType = (sel.edited()) ? 'MSShapePathLayer' : sel.class();
  var selData =  {type: '\"' + shapeType + '\"',
                  name: '\"' + sel.name() + '\"',
                  isVisible: sel.isVisible(),
                  size: '[' + round100(f.width()) + ', ' + round100(f.height())] + ']',
                  // path: '[' + shapePoints.points + ']',
                  // inTangents: '[' + shapePoints.inTangents + ']',
                  // outTangents: '[' + shapePoints.outTangents + ']',
                  // pathClosed: shapePoints.closed,
                  path: getPath(sel),
                  roundness: cornerRoundness,
                  position: '[' + [round100(f.x()), round100(f.y())] + ']',
                  // opacity: Math.round(sel.style().contextSettings().opacity() * 100),
                  rotation: sel.rotation(),
                  booleanOperation: sel.booleanOperation()
                  };

  return objString(selData);
}
function storeOval(sel) {
  // alert(sel.name() + ' :: This is an oval!!!!');
  var f = sel.frame();
  // var shapePoints = layerToPointArray(sel);
  var shapeType = (sel.edited()) ? 'MSShapePathLayer' : sel.class();
  var selData =  {type: '\"' + shapeType + '\"',
                  name: '\"' + sel.name() + '\"',
                  isVisible: sel.isVisible(),
                  size: '[' + round100(f.width()) + ', ' + round100(f.height())] + ']',
                  // path: '[' + shapePoints.points + ']',
                  // inTangents: '[' + shapePoints.inTangents + ']',
                  // outTangents: '[' + shapePoints.outTangents + ']',
                  // pathClosed: shapePoints.closed,
                  path: getPath(sel),
                  position: '[' + [f.x(), f.y()] + ']',
                  // opacity: Math.round(sel.style().contextSettings().opacity() * 100),
                  rotation: sel.rotation(),
                  booleanOperation: sel.booleanOperation()
                  };

  return objString(selData);
}
function storeCompoundShape(sel) {
  // alert(sel.name() + ' :: This is a compound shape!!!!');
  var f = sel.frame();
  // var fillColor = sel.style().fills()[0].color();

  // var shapePoints = shapeToPointArray(sel);
  // var cornerRoundness = 0;
  //     try {cornerRoundness = sel.layers().firstObject().cornerRadiusFloat();} catch(e) {}
  var selData =  {type: '\"' + 'CompoundShape' + '\"',
                  name: '\"' + sel.name() + '\"',
                  isVisible: sel.isVisible(),
                  size: '[' + round100(f.width()) + ', ' + round100(f.height())] + ']',
                  // path: '[' + shapePoints.points + ']',
                  // inTangents: '[' + shapePoints.inTangents + ']',
                  // outTangents: '[' + shapePoints.outTangents + ']',
                  // pathClosed: shapePoints.closed,
                  // roundness: cornerRoundness,
                  position: '[' + [round100(f.x()), round100(f.y())] + ']',
                  opacity: Math.round(sel.style().contextSettings().opacity() * 100),
                  fill: getFills(sel),
                  stroke: getStrokes(sel),
                  shadow: getShadows(sel),
                  layers: getLayersInGroup(sel),
                  blendMode: sel.style().contextSettings().blendMode()
                  };

  function getLayersInGroup(group) {
    var layersInGroup = filterTypes(group.layers());
    return layersInGroup;
  }

  return objString(selData);
}
function storeText(sel) {
  // alert(sel.name() + ' :: This is a text!!!!');

  var f = sel.frame();
  // var hasStroke = (sel.style().borders().length > 0 && sel.style().borders()[0].isEnabled()) ? 1 : 0;
  // var strokeColor = [0,0,0,1];
  // var strokeWeight = 0;
  // // shadows
  // var hasShadow = sel.style().shadows().length > 0 && sel.style().shadows()[0].isEnabled()) ? 1 : 0;
  // var shadowColor = [0,0,0,1];
  // var shadowPos = [0,0];
  // var shadowBlur = 0;
  // var shadowSpread = 0;
  //
  // if (hasStroke) {
  //   strokeColor = sketchColorToArray(sel.style().borders()[0].color());
  //   strokeWeight = sel.style().borders()[0].thickness();
  // }
  // if (hasShadow) {
  //   shadowColor = sketchColorToArray(sel.style().shadows()[0].color());
  //   shadowPos = [sel.style().shadows()[0].offsetX(), sel.style().shadows()[0].offsetY()];
  //   shadowBlur = sel.style().shadows()[0].blurRadius();
  //   shadowSpread = sel.style().shadows()[0].spread();
  // }

  var selData =  {type: '\"' + sel.class() + '\"',
                  name: '\"' + sel.name() + '\"',
                  isVisible: sel.isVisible(),
                  stringVal: '\"' + sel.stringValue().replace(/\n/g, '\\n') + '\"',
                  size: '[' + round100(f.width()) + ', ' + round100(f.height())] + ']',
                  opacity: Math.round(sel.style().contextSettings().opacity() * 100),
                  position: '[' + [round100(f.x()), round100(f.y())] + ']',
                  fontName: '\"' + sel.fontPostscriptName() + '\"',
                  fontSize: sel.fontSize(),
                  // tracking: (sel.kerning() == 'Infinity') ? 0 : round100(sel.fontSize() / 2 / sel.kerning()),
                  tracking: Math.min(round100(sel.fontSize() / 2 / sel.kerning()), 0),
                  justification: sel.textAlignment(),
                  lineHeight: (sel.lineHeight() == 0) ? Math.round(sel.fontSize() * 1.14) : sel.lineHeight(),
                  hasFill: Math.ceil(sketchColorToOpacity(sel.textColor())/100 ),
                  textColor: '[' + sketchColorToArray(sel.textColor()) + ']',
                  fill: getFills(sel),
                  stroke: getStrokes(sel),
                  shadow: getShadows(sel),
                  blendMode: sel.style().contextSettings().blendMode()
                  // hasStroke: hasStroke,
                  // strokeColor: '[' + strokeColor + ']',
                  // strokeWeight: strokeWeight,
                  // hasShadow: hasShadow,
                  // shadowColor: '[' + shadowColor + ']',
                  // shadowPos: '[' + shadowPos + ']',
                  // shadowBlur: shadowBlur,
                  // shadowSpread: shadowSpread
                  };


  return objString(selData);
}
function storeGroup(sel) {
  var f = sel.frame();
  // alert(sel.name() + ' :: This is a group');
  var selData = { type: '\"' + sel.class() + '\"',
                  name: '\"' + sel.name() + '\"',
                  size: '[' + round100(f.width()) + ', ' + round100(f.height())] + ']',
                  position: '[' + [f.x(), f.y()] + ']',
                  // opacity: Math.round(sel.style().contextSettings().opacity() * 100),
                  // depth: sel.layers().length,
                  hasClippingMask: sel.layers()[0].hasClippingMask(),
                  layers: getLayersInGroup(sel)
  }

  function getLayersInGroup(group) {
    var layersInGroup = filterTypes(group.layers());
    return layersInGroup;
  }

  return objString(selData);
}
function storeSymbol(sel) {
  var f = sel.frame();
  var masterSymbolSize = null;

  // shadows
  var hasShadow = sel.style().shadows().length > 0 && sel.style().shadows()[0].isEnabled()) ? 1 : 0;
  var shadowColor = [0,0,0,1];
  var shadowPos = [0,0];
  var shadowBlur = 0;
  var shadowSpread = 0;
  if (hasShadow) {
    shadowColor = sketchColorToArray(sel.style().shadows()[0].color());
    shadowPos = [sel.style().shadows()[0].offsetX(), sel.style().shadows()[0].offsetY()];
    shadowBlur = sel.style().shadows()[0].blurRadius();
    shadowSpread = sel.style().shadows()[0].spread();
  }

  var selData = { type: '\"' + sel.class() + '\"',
                  name: '\"' + sel.name() + '\"',
                  size: '[' + round100(f.width()) + ', ' + round100(f.height())] + ']',
                  opacity: Math.round(sel.style().contextSettings().opacity() * 100),
                  position: '[' + [f.x(), f.y()] + ']',
                  symbolID: '\"' + sel.symbolID() + '\"',
                  hasShadow: hasShadow,
                  shadowColor: '[' + shadowColor + ']',
                  shadowPos: '[' + shadowPos + ']',
                  shadowBlur: shadowBlur,
                  shadowSpread: shadowSpread,
                  blendMode: sel.style().contextSettings().blendMode(),
                  layers: getMasterSymbol(sel),
                  symbolSize: masterSymbolSize
  }

  function getMasterSymbol(instance) {
    var selID = instance.symbolID();
    var masterSymbol = 'farts';
    for (var i = 0; i < sketchFile.document.pages().length; i++) {
        var artBoard = sketchFile.document.pages()[i];
        for (var j = 0; j < artBoard.children().length; j++) {

          try {
            var currentID = String(artBoard.children()[j].symbolID());
            if (currentID == selID && artBoard.children()[j].class() == 'MSSymbolMaster') {
              masterSymbol = artBoard.children()[j];
              break;
            }
          } catch(e) {}
        }
      }
      // alert(masterSymbol)
    var layersInGroup = filterTypes(masterSymbol.layers());
    masterSymbolSize = '[' + masterSymbol.frame().width() + ', ' +  masterSymbol.frame().height() + ']';
    // masterSymbolSize = masterSymbol.frame().w;
    return layersInGroup;
  }

  return objString(selData);
}
// function storeGroup(sel) {
//   var f = sel.frame();
//   // alert(sel.name() + ' :: This is a group');
//   var selData = { type: '\"' + sel.layers().firstObject().class() + '\"',
//                   name: '\"' + sel.name() + '\"',
//                   size: '[' + round100(f.width()) + ', ' + round100(f.height())] + ']',
//                   position: '[' + [f.x(), f.y()] + ']',
//                   depth: sel.layers().length,
//                   layers: getLayersInGroup(sel)
//   }
//
//   function getLayersInGroup(group) {
//     var layersInGroup = filterTypes(group.layers());
//     // for (var i = 0; i < group.layers().length; i++) {
//     //   layersInGroup.push(filterTypes(group.layers()[i]));
//     // }
//
//     return layersInGroup;
//   }
//
//   return objString(selData);
// }
function storeImg(sel) {
  imageInc++;
  getFolderPath();
  var parentPage_index = pages.indexOfObject(getParentPage(sel));
  var imageFile = exportLayer(sel, folderPath);

  var f = sel.frame();
  var selData = { type: '\"' + sel.class() + '\"',
                  name: '\"' + sel.name() + '\"',
                  fileName: imageFile.fileName,
                  path: imageFile.path,
                  // size: '[' + round100(f.width()) + ', ' + round100(f.height())] + ']',
                  position: '[' + [f.x(), f.y()] + ']',
                  opacity: Math.round(sel.style().contextSettings().opacity() * 100),
                  scale: imageFile.scale,
                  blendMode: sel.style().contextSettings().blendMode()
                  // // depth: sel.layers().length,
                  // hasClippingMask: sel.layers()[0].hasClippingMask()
                  // layers: getLayersInGroup(sel)
  }

  return objString(selData);

  function exportLayer(layer, path) {
    // var rect = layer.absoluteRect().rect();
    var rect = layer.absoluteRect().rect();
    var imageWidth = layer.image().image().size().width;
    var screenWidth = rect.size.width;
    var scale = imageWidth/screenWidth;
    var slice = [MSExportRequest requestWithRect:rect scale:scale];
        slice.setShouldTrim(0);
        slice.setSaveForWeb(0);
        slice.configureForLayer(layer);
    var filename = layer.name() + '_' + imageInc + '.png';

    doc.setCurrentPage(pages[parentPage_index]);                    // switch page to parent of image
    doc.saveArtboardOrSlice_toFile(slice, path + filename);         // export layer

    return {
      fileName: '\"' + filename + '\"',
      path: '\"' + path + '\"',
      imageWidth: imageWidth,
      scale: scale
    }
  }
}
function storeImgFill(sel) {
  imageInc++;
  getFolderPath();
  var parentPage_index = pages.indexOfObject(getParentPage(sel));
  var imageFile = exportLayer(sel, folderPath);

  var f = sel.frame();
  var selData = { type: '\"' + 'MSBitmapLayer' + '\"',
                  name: '\"' + sel.name() + '\"',
                  fileName: imageFile.fileName,
                  path: imageFile.path,
                  // size: '[' + round100(f.width()) + ', ' + round100(f.height())] + ']',
                  position: '[' + [f.x(), f.y()] + ']',
                  opacity: Math.round(sel.style().contextSettings().opacity() * 100),
                  scale: imageFile.scale,
                  blendMode: sel.style().contextSettings().blendMode()
                  // // depth: sel.layers().length,
                  // hasClippingMask: sel.layers()[0].hasClippingMask()
                  // layers: getLayersInGroup(sel)
  }

  return objString(selData);

  function exportLayer(layer, path) {
    var rect = layer.absoluteRect().rect();
    var scale = 4;
    var slice = [MSExportRequest requestWithRect:rect scale:scale];
        slice.setShouldTrim(0);
        slice.setSaveForWeb(0);
        slice.configureForLayer(layer);
    var filename = layer.name()  + '_' + imageInc + '.png';

    doc.setCurrentPage(pages[parentPage_index]);                    // switch page to parent of image
    doc.saveArtboardOrSlice_toFile(slice, path + filename);         // export layer
    return {
      fileName: '\"' + filename + '\"',
      path: '\"' + path + '\"',
      scale: scale
    }
  }
}
function getPathGroup(sel) {
  var hasPath = (sel[0].edited()) ? 1 : 0;

  if (hasPath) {
    var shapeLayer = sel;
    var count = 0;
    var path = NSArray.arrayWithObject(shapeLayer).objectEnumerator().nextObject()[0].path();
    var points = [], inTangents = [], outTangents = [];
    var shapeSize = {
      w: sel.firstObject().frame().width(),
      h: sel.firstObject().frame().height()
    };
    while (path.pointAtIndex(count) !== null) {
      var p = [round100(path.pointAtIndex(count).point().x * shapeSize.w), round100(path.pointAtIndex(count).point().y * shapeSize.h) ];

      if (path.pointAtIndex(count).curveMode() !== 1) {
        var o = [round100(path.pointAtIndex(count).curveFrom().x * shapeSize.w - p[0]), round100(path.pointAtIndex(count).curveFrom().y * shapeSize.h - p[1]) ];
        var i = [round100(path.pointAtIndex(count).curveTo().x * shapeSize.w - p[0]), round100(path.pointAtIndex(count).curveTo().y * shapeSize.h - p[1])];
      } else {
        var o = [0,0];
        var i = [0,0];
      }

      points.push('[' + p + ']');
      inTangents.push('[' + i + ']');
      outTangents.push('[' + o + ']');
      count++;
    }
    var pathObj = {
      points: '[' + points + ']',
      inTangents: '[' + inTangents + ']',
      outTangents: '[' + outTangents + ']',
      closed: path.isClosed()
    }
    return objString(pathObj);
  } else {
    return null;
  }
}
function getPath(sel) {
  var hasPath = (sel.edited()) ? 1 : 0;
  if (hasPath) {
    var shapeLayer = sel;
    var count = 0;
    var path = NSArray.arrayWithObject(shapeLayer).objectEnumerator().nextObject().path();
    var points = [], inTangents = [], outTangents = [];
    var shapeSize = {
      w: sel.frame().width(),
      h: sel.frame().height()
    };
    while (path.pointAtIndex(count) !== null) {
      var p = [round100(path.pointAtIndex(count).point().x * shapeSize.w), round100(path.pointAtIndex(count).point().y * shapeSize.h) ];

      if (path.pointAtIndex(count).curveMode() !== 1) {
        var o = [round100(path.pointAtIndex(count).curveFrom().x * shapeSize.w - p[0]), round100(path.pointAtIndex(count).curveFrom().y * shapeSize.h - p[1]) ];
        var i = [round100(path.pointAtIndex(count).curveTo().x * shapeSize.w - p[0]), round100(path.pointAtIndex(count).curveTo().y * shapeSize.h - p[1])];
      } else {
        var o = [0,0];
        var i = [0,0];
      }

      points.push('[' + p + ']');
      inTangents.push('[' + i + ']');
      outTangents.push('[' + o + ']');
      count++;
    }
    var pathObj = {
      points: '[' + points + ']',
      inTangents: '[' + inTangents + ']',
      outTangents: '[' + outTangents + ']',
      closed: path.isClosed()
    }
    return objString(pathObj);
  } else {
    return null;
  }
}
function getShadows(sel) {
  var hasShadow = (sel.style().shadows().length > 0 && sel.style().shadows()[0].isEnabled()) ? 1 : 0;

  if (hasShadow) {
    var shadowData = []
      for (var i = 0; i < sel.style().shadows().length; i++) {
        var shadowObj = {
          color: '[' + sketchColorToArray(sel.style().shadows()[i].color()) + ']',
          position: '[' + [sel.style().shadows()[i].offsetX(), sel.style().shadows()[i].offsetY()] + ']',
          blur: sel.style().shadows()[i].blurRadius(),
          spread: sel.style().shadows()[i].spread()
        }
        var shadowProps = objString(shadowObj)
        shadowData.push(shadowProps)
      }
    return '[' + shadowData + ']';
  } else {
    return null;
  }
}
function getStrokes(sel) {
  var hasStroke = (sel.style().borders().length > 0) ? 1 : 0;

  if (hasStroke) {
    var strokeData = []
      for (var i = 0; i < sel.style().borders().length; i++) {
        var strokeObj = {
          enabled: sel.style().borders()[i].isEnabled(),
          color: '[' + sketchColorToArray(sel.style().borders()[i].color()) + ']',
          opacity: sketchColorToOpacity(sel.style().borders()[i].color()),
          width: sel.style().borders()[i].thickness(),
          cap: sel.style().borderOptions().lineCapStyle(),
          join: sel.style().borderOptions().lineJoinStyle()
        }
        var strokeProps = objString(strokeObj)
        strokeData.push(strokeProps)
      }
    return '[' + strokeData + ']';
  } else {
    return null;
  }
}
function getFills(sel) {
  var hasFill = (sel.style().fills().length > 0) ? 1 : 0;

  if (hasFill) {
    var strokeData = []
      for (var i = 0; i < sel.style().fills().length; i++) {
        var strokeObj = {
          enabled: sel.style().fills()[i].isEnabled(),
          color: '[' + sketchColorToArray(sel.style().fills()[i].color()) + ']',
          opacity: sketchColorToOpacity(sel.style().fills()[i].color()),
          blendMode: sel.style().fills()[i].contextSettings().blendMode()
        }
        var strokeProps = objString(strokeObj)
        strokeData.push(strokeProps)
      }
    return '[' + strokeData + ']';
  } else {
    return null;
  }
}
function getParentPage(layer) {
  if (layer.parentGroup() !== null) {
    return getParentPage(layer.parentGroup());
  } else {
    return layer;
  }
}
// function getShadows(sel, selData) {
//   var hasShadow = sel.style().shadows().length > 0 && sel.style().shadows()[0].isEnabled()) ? 1 : 0;
//
//   selData.hasShadow = hasShadow;
//
//   if (hasShadow) {
//     selData.shadowColor = '[' + sketchColorToArray(sel.style().shadows()[0].color()) + ']';
//     selData.shadowPos = '[' + [sel.style().shadows()[0].offsetX(), sel.style().shadows()[0].offsetY()] + ']';
//     selData.shadowBlur = sel.style().shadows()[0].blurRadius();
//     selData.shadowSpread = sel.style().shadows()[0].spread();
//   }
// }
function sketchColorToArray(c) {
  var colorArray = c.toString().slice(1,-1);  // remove parenthesis
      colorArray = (colorArray.replace('r:', ''));
      colorArray = colorArray.replace(' g:', ', ');
      colorArray = colorArray.replace(' b:', ', ');
      colorArray = colorArray.replace(' a:', ', ');
  return colorArray;
}
function sketchColorToOpacity(c) {
  var colorArray = c.toString().slice(1,-1);  // remove parenthesis
      colorArray = colorArray.split(' a:')[1];
  return colorArray * 100;
}
// function shapeToPointArray(sel) {
//   var shapeLayer = sel.layers();
//   var count = 0;
//   var path = NSArray.arrayWithObject(shapeLayer).objectEnumerator().nextObject()[0].path();
//   var points = [], inTangents = [], outTangents = [];
//   var shapeSize = {
//     w: sel.frame().width(),
//     h: sel.frame().height()
//   };
//   while (path.pointAtIndex(count) !== null) {
//     var p = [round100(path.pointAtIndex(count).point().x * shapeSize.w), round100(path.pointAtIndex(count).point().y * shapeSize.h) ];
//
//     if (path.pointAtIndex(count).curveMode() !== 1) {
//       // var o = [ round100(path.pointAtIndex(count).curveTo().x * -shapeSize.w + p[0]), round100(path.pointAtIndex(count).curveTo().y * -shapeSize.h + p[1]) ];
//       // var i = [ round100(path.pointAtIndex(count).curveFrom().x * -shapeSize.w + p[0]), round100(path.pointAtIndex(count).curveFrom().y * -shapeSize.h + p[1])];
//       var o = [round100(path.pointAtIndex(count).curveFrom().x * shapeSize.w - p[0]), round100(path.pointAtIndex(count).curveFrom().y * shapeSize.h - p[1]) ];
//       var i = [round100(path.pointAtIndex(count).curveTo().x * shapeSize.w - p[0]), round100(path.pointAtIndex(count).curveTo().y * shapeSize.h - p[1])];
//     } else {
//       var o = [0,0];
//       var i = [0,0];
//     }
//     // var i = [ round100(path.pointAtIndex(count).curveTo().y * -shapeSize.h + p[1]), round100(path.pointAtIndex(count).curveTo().x * -shapeSize.w + p[0]) ];
//     // var o = [ round100(path.pointAtIndex(count).curveFrom().x * -shapeSize.w + p[0]), round100(path.pointAtIndex(count).curveFrom().y * -shapeSize.h + p[1])];
//     // var o = [0,0];
//
//     points.push('[' + p + ']');
//     inTangents.push('[' + i + ']');
//     outTangents.push('[' + o + ']');
//     count++;
//   }
//   return {
//     'points': points,
//     'inTangents': inTangents,
//     'outTangents': outTangents,
//     'closed': path.isClosed()
//   };
// }
// function layerToPointArray(sel) {
//   var shapeLayer = sel;
//   var count = 0;
//   var path = NSArray.arrayWithObject(shapeLayer).objectEnumerator().nextObject().path();
//   var points = [], inTangents = [], outTangents = [];
//   var shapeSize = {
//     w: sel.frame().width(),
//     h: sel.frame().height()
//   };
//   while (path.pointAtIndex(count) !== null) {
//     var p = [round100(path.pointAtIndex(count).point().x * shapeSize.w), round100(path.pointAtIndex(count).point().y * shapeSize.h) ];
//     if (path.pointAtIndex(count).curveMode() !== 1) {
//       // var o = [ round100(path.pointAtIndex(count).curveTo().x * -shapeSize.w + p[0]), round100(path.pointAtIndex(count).curveTo().y * -shapeSize.h + p[1]) ];
//       // var i = [ round100(path.pointAtIndex(count).curveFrom().x * -shapeSize.w + p[0]), round100(path.pointAtIndex(count).curveFrom().y * -shapeSize.h + p[1])];
//       var o = [round100(path.pointAtIndex(count).curveFrom().x * shapeSize.w - p[0]), round100(path.pointAtIndex(count).curveFrom().y * shapeSize.h - p[1])];
//       var i = [round100(path.pointAtIndex(count).curveTo().x * shapeSize.w - p[0]), round100(path.pointAtIndex(count).curveTo().y * shapeSize.h - p[1])];
//     } else {
//       var o = [0,0];
//       var i = [0,0];
//     }
//     points.push('[' + p + ']');
//     inTangents.push('[' + i + ']');
//     outTangents.push('[' + o + ']');
//     count++;
//   }
//   return {
//     'points': points,
//     'inTangents': inTangents,
//     'outTangents': outTangents,
//     'closed': path.isClosed()
//   };
// }
// function isPathClosed(sel) {
//   var shapeLayer = sel.layers();
//   var path = NSArray.arrayWithObject(shapeLayer).objectEnumerator().nextObject()[0].path();
//   return path.isClosed();
// }         // depreciated
function round100(num) {
  return Math.round(num * 100) / 100;
}

// var onSelectionChanged = function(context) {
//     action = context.actionContext;
//     document = action.document;
//     selection = action.newSelection;
//     count = selection.count();
//     if (count < 1) {
//       document.hideMessage();
//     } else {
//       if (count == 1) {
//         message = "1 layer selected."
//       } else {
//         app.displayDialog_withTitle('Hey there wow', 'you ball bag');
//         message = count + " layers selected.";
//
//       }
//       document.showMessage(message);
//     }
// };

// while (shapePathLayer = loopPaths.nextObject()) {
//         var threshold = (typeof threshold === 'undefined' || threshold == nil) ? 1.2 : threshold,
//             shapeFrame = shapePathLayer.frame(),
//             shapeWidth = shapeFrame.width(),
//             shapeHeight = shapeFrame.height(),
//             shapePath = shapePathLayer.path(),
//             prevPoint = shapePath.firstPoint(),
//             point = prevPoint.point(),
//             prevCGPoint = CGPointMake(point.x*shapeWidth, point.y*shapeHeight),
//             newPoints = [],
//             count = shapePath.numberOfPoints(),
//             excludePrev = false,
//             i, currPoint, currCGPoint;
